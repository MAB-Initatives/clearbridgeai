'use client'

import Button from './Button'
import { AlertTriangleIcon } from './icons'

interface ErrorStepProps {
  message: string
  onRetry: () => void
  onStartOver: () => void
}

export default function ErrorStep({ message, onRetry, onStartOver }: ErrorStepProps) {
  return (
    <div className="flex min-h-[420px] flex-col items-center justify-center text-center animate-fade-up">
      <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-full bg-error-100 dark:bg-error-600/10">
        <AlertTriangleIcon className="h-6 w-6 text-error-600" />
      </div>
      <p className="font-display text-lg font-semibold text-error-700">Analysis failed</p>
      <p className="mt-2 max-w-sm text-sm text-ink-600 dark:text-fog-300">{message}</p>
      <div className="mt-6 flex items-center gap-3">
        <Button onClick={onRetry}>Retry</Button>
        <Button variant="ghost" onClick={onStartOver}>
          Edit document
        </Button>
      </div>
    </div>
  )
}

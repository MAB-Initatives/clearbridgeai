export default function GemmaBadge({ className = '' }: { className?: string }) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border border-bridge-600/20 bg-bridge-100/60 px-3 py-1 font-mono text-xs font-medium text-bridge-600 dark:border-bridge-500/30 dark:bg-bridge-500/10 dark:text-bridge-500 ${className}`}
    >
      <span className="h-1.5 w-1.5 rounded-full bg-bridge-600 dark:bg-bridge-500" aria-hidden="true" />
      Powered by Gemma
    </span>
  )
}

'use client'

import Button from './Button'
import GemmaBadge from './GemmaBadge'
import { FileTextIcon, ClockIcon, ListChecksIcon, AlertTriangleIcon, ArrowRightIcon } from './icons'
import { getUrgency, type UrgencyTone } from '@/lib/urgency'
import type { AnalysisResult } from '@/lib/types'

interface ResultsStepProps {
  analysis: AnalysisResult
  onAskFollowUp: () => void
  onAnalyzeAnother: () => void
}

const urgencyStyles: Record<UrgencyTone, string> = {
  urgent: 'bg-error-100 text-error-700 dark:bg-error-600/10',
  soon: 'bg-warning-100 text-warning-700 dark:bg-warning-600/10',
  normal: 'bg-bridge-100 text-bridge-600 dark:bg-bridge-500/10 dark:text-bridge-500',
  passed: 'bg-mist-100 text-ink-600 dark:bg-ink-900 dark:text-fog-300',
}

function Quote({ text, accentClass }: { text: string; accentClass: string }) {
  if (!text) return null
  return (
    <p className={`ml-4 mt-1 border-l-2 ${accentClass} pl-2.5 text-xs italic text-ink-600 dark:text-fog-300`}>
      “{text}”
    </p>
  )
}

export default function ResultsStep({ analysis, onAskFollowUp, onAnalyzeAnother }: ResultsStepProps) {
  return (
    <div className="animate-fade-up">
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="mb-1 inline-flex items-center gap-1.5 text-xs font-medium text-success-600">
            <span className="h-1.5 w-1.5 rounded-full bg-success-600" aria-hidden="true" />
            Analysis complete
          </p>
          <h1 className="font-display text-3xl font-bold tracking-tight sm:text-4xl">Your decision brief</h1>
        </div>
        <GemmaBadge />
      </div>

      <div className="space-y-4">
        {/* Bottom line — the verdict a reader should see first, before any detail */}
        <section className="rounded-lg border-2 border-bridge-600 bg-bridge-100/60 p-6 dark:border-bridge-500 dark:bg-bridge-500/10">
          <p className="mb-1.5 font-mono text-xs font-medium uppercase tracking-wide text-bridge-600 dark:text-bridge-500">
            Bottom line
          </p>
          <p className="font-display text-xl font-bold leading-snug text-ink-950 dark:text-mist-50">
            {analysis.bottom_line}
          </p>
        </section>

        <section className="rounded-lg border border-mist-200 bg-white p-6 shadow-card dark:border-ink-900 dark:bg-ink-900/40">
          <div className="mb-3 flex items-center gap-2">
            <FileTextIcon className="h-4 w-4 text-bridge-600 dark:text-bridge-500" />
            <h2 className="font-display text-sm font-semibold">What this document is</h2>
          </div>
          <p className="text-[15px] leading-relaxed text-ink-950 dark:text-mist-50">{analysis.summary}</p>
        </section>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <section className="rounded-lg border border-mist-200 bg-white p-6 shadow-card dark:border-ink-900 dark:bg-ink-900/40">
            <div className="mb-3 flex items-center gap-2">
              <ClockIcon className="h-4 w-4 text-bridge-600 dark:text-bridge-500" />
              <h2 className="font-display text-sm font-semibold">Key dates</h2>
            </div>
            {analysis.key_dates.length === 0 ? (
              <p className="text-sm text-ink-600 dark:text-fog-300">No specific dates found in this document.</p>
            ) : (
              <ul className="space-y-3">
                {analysis.key_dates.map((d, i) => {
                  const urgency = getUrgency(d.iso_date)
                  return (
                    <li key={i} className="text-sm">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-medium text-ink-950 dark:text-mist-50">{d.date}</span>
                        {urgency && (
                          <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${urgencyStyles[urgency.tone]}`}>
                            {urgency.label}
                          </span>
                        )}
                      </div>
                      <p className="text-ink-600 dark:text-fog-300">{d.label}</p>
                    </li>
                  )
                })}
              </ul>
            )}
          </section>

          <section className="rounded-lg border border-mist-200 bg-white p-6 shadow-card dark:border-ink-900 dark:bg-ink-900/40">
            <div className="mb-3 flex items-center gap-2">
              <ListChecksIcon className="h-4 w-4 text-bridge-600 dark:text-bridge-500" />
              <h2 className="font-display text-sm font-semibold">Key highlights</h2>
            </div>
            {analysis.key_highlights.length === 0 ? (
              <p className="text-sm text-ink-600 dark:text-fog-300">No additional highlights beyond the summary.</p>
            ) : (
              <ul className="space-y-3">
                {analysis.key_highlights.map((h, i) => (
                  <li key={i} className="text-sm">
                    <p className="flex gap-2 text-ink-950 dark:text-mist-50">
                      <span className="text-bridge-600 dark:text-bridge-500" aria-hidden="true">•</span>
                      {h.point}
                    </p>
                    <Quote text={h.quote} accentClass="border-mist-200 dark:border-ink-900" />
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>

        {analysis.risks.length > 0 && (
          <section className="rounded-lg border border-warning-600/25 bg-warning-100 p-6 dark:bg-warning-600/10">
            <div className="mb-3 flex items-center gap-2">
              <AlertTriangleIcon className="h-4 w-4 text-warning-700" />
              <h2 className="font-display text-sm font-semibold text-warning-700">Watch out for</h2>
            </div>
            <ul className="space-y-3">
              {analysis.risks.map((r, i) => (
                <li key={i} className="text-sm">
                  <p className="flex gap-2 text-ink-950 dark:text-mist-50">
                    <span className="text-warning-700" aria-hidden="true">•</span>
                    {r.point}
                  </p>
                  <Quote text={r.quote} accentClass="border-warning-600/30" />
                </li>
              ))}
            </ul>
          </section>
        )}

        <section className="rounded-lg border border-bridge-600/30 bg-bridge-100/60 p-6 dark:border-bridge-500/30 dark:bg-bridge-500/10">
          <div className="mb-3 flex items-center gap-2">
            <ArrowRightIcon className="h-4 w-4 text-bridge-600 dark:text-bridge-500" />
            <h2 className="font-display text-sm font-semibold text-bridge-600 dark:text-bridge-500">
              Recommended next steps
            </h2>
          </div>
          <ol className="space-y-4 text-[15px] text-ink-950 dark:text-mist-50">
            {analysis.next_steps.map((step, i) => (
              <li key={i} className="flex gap-3">
                <span className="flex h-5 w-5 flex-shrink-0 items-center justify-center rounded-full bg-bridge-600 text-xs font-semibold text-white">
                  {i + 1}
                </span>
                <div className="flex-1">
                  <p>{step.action}</p>
                  <p className="mt-0.5 text-sm text-ink-600 dark:text-fog-300">{step.reason}</p>
                  <Quote text={step.quote} accentClass="border-bridge-600/30" />
                </div>
              </li>
            ))}
          </ol>
        </section>
      </div>

      <div className="mt-8 flex flex-wrap items-center gap-3">
        <Button size="lg" onClick={onAskFollowUp}>
          Ask a follow-up question
        </Button>
        <Button variant="ghost" onClick={onAnalyzeAnother}>
          Analyze another document
        </Button>
      </div>
    </div>
  )
}

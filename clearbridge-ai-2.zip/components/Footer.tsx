export default function Footer() {
  return (
    <footer className="border-t border-mist-200 py-8 dark:border-ink-900">
      <div className="mx-auto max-w-6xl px-4 text-center text-xs text-ink-600 dark:text-fog-300 sm:px-6">
        ClearBridge AI — built for a hackathon. Every explanation, highlight, date, and next
        step on this page is generated live by Gemma.
      </div>
    </footer>
  )
}

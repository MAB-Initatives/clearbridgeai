import Link from 'next/link'
import ThemeToggle from './ThemeToggle'
import Button from './Button'
import GemmaBadge from './GemmaBadge'

export default function Navbar({ variant = 'landing' }: { variant?: 'landing' | 'assistant' }) {
  return (
    <header className="sticky top-0 z-40 border-b border-mist-200/70 bg-mist-50/80 backdrop-blur-md dark:border-ink-900/70 dark:bg-ink-950/80">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
        <Link href="/" className="flex items-center gap-2 font-display text-[17px] font-bold">
          <span className="flex h-8 w-8 items-center justify-center rounded-md bg-bridge-600 text-sm text-white">
            CB
          </span>
          ClearBridge AI
        </Link>

        <div className="hidden sm:block">
          <GemmaBadge />
        </div>

        <nav className="flex items-center gap-2 sm:gap-3">
          <ThemeToggle />
          {variant === 'landing' ? (
            <Link href="/assistant">
              <Button size="md">
                <span className="hidden sm:inline">Analyze a document</span>
                <span className="sm:hidden">Analyze</span>
              </Button>
            </Link>
          ) : (
            <Link href="/">
              <Button size="md" variant="secondary">
                Home
              </Button>
            </Link>
          )}
        </nav>
      </div>
    </header>
  )
}

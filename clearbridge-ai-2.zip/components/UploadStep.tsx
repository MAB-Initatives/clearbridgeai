'use client'

import { useEffect, useRef, useState, type DragEvent } from 'react'
import Button from './Button'
import { UploadIcon, CameraIcon, FileTextIcon, SparkleIcon } from './icons'
import { extractTextFromFile } from '@/lib/pdf-extract'
import { prepareImage, isAcceptedImageType, type PreparedImage } from '@/lib/image-prepare'
import type { DocumentInput } from '@/lib/types'

const EXAMPLE_TEXT = `Applicants must have a WAEC result with a minimum of 5 credits including English and Mathematics. Completed applications, along with certified copies of the WAEC result, birth certificate, and passport photograph, must be received no later than August 15. Late or incomplete submissions will not be considered.`

const ALLOWED_TEXT_EXTENSIONS = ['.txt', '.md']

function isSupportedTextFile(file: File): boolean {
  const name = file.name.toLowerCase()
  if (ALLOWED_TEXT_EXTENSIONS.some((ext) => name.endsWith(ext))) return true
  return file.type === 'text/plain' || file.type === 'text/markdown'
}

interface UploadStepProps {
  onAnalyze: (input: DocumentInput) => void
}

export default function UploadStep({ onAnalyze }: UploadStepProps) {
  const [text, setText] = useState('')
  const [fileName, setFileName] = useState<string | null>(null)
  const [image, setImage] = useState<PreparedImage | null>(null)
  const [fileError, setFileError] = useState<string | null>(null)
  const [processingKind, setProcessingKind] = useState<'text' | 'image' | null>(null)
  const [isDragging, setIsDragging] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const cameraInputRef = useRef<HTMLInputElement>(null)

  // Avoid leaking the preview's object URL when it's replaced or the screen unmounts.
  useEffect(() => {
    return () => {
      if (image) URL.revokeObjectURL(image.previewUrl)
    }
  }, [image])

  function clearImage() {
    if (image) URL.revokeObjectURL(image.previewUrl)
    setImage(null)
  }

  async function handleFile(file: File) {
    setFileError(null)

    if (isSupportedTextFile(file)) {
      clearImage()
      setProcessingKind('text')
      try {
        const extracted = await extractTextFromFile(file)
        if (!extracted.trim()) {
          throw new Error('No readable text was found in that file.')
        }
        setText(extracted)
        setFileName(file.name)
      } catch (err) {
        setFileError(
          err instanceof Error
            ? `${err.message} Try pasting the text directly instead.`
            : "Couldn't read that file. Try pasting the text directly instead."
        )
      } finally {
        setProcessingKind(null)
      }
      return
    }

    if (isAcceptedImageType(file)) {
      setText('')
      setFileName(null)
      setProcessingKind('image')
      try {
        const prepared = await prepareImage(file)
        clearImage()
        setImage(prepared)
      } catch (err) {
        setFileError(err instanceof Error ? err.message : "Couldn't process that image.")
      } finally {
        setProcessingKind(null)
      }
      return
    }

    setFileError(
      'ClearBridge reads .txt, .md, JPG, PNG, and WEBP files right now. Try pasting the text instead.'
    )
  }

  function handleDrop(e: DragEvent<HTMLDivElement>) {
    e.preventDefault()
    setIsDragging(false)
    const file = e.dataTransfer.files?.[0]
    if (file) handleFile(file)
  }

  function handleAnalyze() {
    if (image) {
      onAnalyze({ type: 'image', mimeType: image.mimeType, data: image.data })
    } else if (text.trim()) {
      onAnalyze({ type: 'text', text })
    }
  }

  const hasContent = Boolean(image) || text.trim().length > 0

  return (
    <div className="animate-fade-up">
      <div className="mb-8 max-w-2xl">
        <h1 className="font-display text-3xl font-bold tracking-tight sm:text-4xl">
          Upload your document
        </h1>
        <p className="mt-3 text-[15px] leading-relaxed text-ink-600 dark:text-fog-300">
          Paste text, drop a .txt or .md file, or upload a photo of a printed document. Gemma will
          explain it, flag dates and risks, and tell you exactly what to do next.
        </p>
      </div>

      <div
        onDragOver={(e) => {
          e.preventDefault()
          setIsDragging(true)
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        className={`rounded-lg border-2 border-dashed p-5 transition-colors sm:p-6 ${
          isDragging ? 'border-bridge-500 bg-bridge-100/40' : 'border-mist-200 dark:border-ink-900'
        }`}
      >
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <label htmlFor="doc-text" className="font-display text-sm font-semibold">
            Your document
          </label>
          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex items-center gap-1.5 text-sm font-medium text-bridge-600 hover:text-bridge-700 dark:text-bridge-500 dark:hover:text-bridge-500/80"
            >
              <UploadIcon className="h-4 w-4" />
              Upload a file
            </button>
            <button
              type="button"
              onClick={() => cameraInputRef.current?.click()}
              className="inline-flex items-center gap-1.5 text-sm font-medium text-bridge-600 hover:text-bridge-700 dark:text-bridge-500 dark:hover:text-bridge-500/80"
            >
              <CameraIcon className="h-4 w-4" />
              Take a photo
            </button>
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept=".txt,.md,text/plain,text/markdown,image/jpeg,image/png,image/webp"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0]
              if (file) handleFile(file)
              e.target.value = ''
            }}
          />
          <input
            ref={cameraInputRef}
            type="file"
            accept="image/*"
            capture="environment"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0]
              if (file) handleFile(file)
              e.target.value = ''
            }}
          />
        </div>

        {image ? (
          <div className="rounded-md border border-mist-200 bg-mist-50 p-3 dark:border-ink-900 dark:bg-ink-950">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={image.previewUrl}
              alt="Document preview"
              className="mx-auto max-h-80 w-auto rounded object-contain"
            />
            <div className="mt-3 flex items-center justify-between">
              <p className="text-xs text-ink-600 dark:text-fog-300">Photo ready · {image.sizeLabel}</p>
              <button
                type="button"
                onClick={clearImage}
                className="text-xs font-medium text-bridge-600 hover:text-bridge-700 dark:text-bridge-500"
              >
                Remove
              </button>
            </div>
          </div>
        ) : (
          <textarea
            id="doc-text"
            value={text}
            onChange={(e) => {
              setText(e.target.value)
              if (fileName) setFileName(null)
            }}
            placeholder="Paste your document here, or drop a file anywhere in this box…"
            rows={12}
            className="w-full resize-none rounded-md border border-mist-200 bg-mist-50 p-4 text-[15px] leading-relaxed text-ink-950 placeholder:text-fog-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bridge-500 dark:border-ink-900 dark:bg-ink-950 dark:text-mist-50"
          />
        )}

        {fileName && !image && (
          <p className="mt-2 flex items-center gap-1.5 text-xs text-ink-600 dark:text-fog-300">
            <FileTextIcon className="h-3.5 w-3.5" />
            Loaded from {fileName}
          </p>
        )}
        {processingKind && (
          <p className="mt-2 text-xs text-ink-600 dark:text-fog-300">
            {processingKind === 'image' ? 'Preparing your photo…' : 'Reading your file…'}
          </p>
        )}
        {fileError && (
          <p className="mt-2 rounded-md bg-error-100 px-3 py-2 text-xs text-error-700 dark:bg-error-600/10">
            {fileError}
          </p>
        )}

        <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => {
              clearImage()
              setText(EXAMPLE_TEXT)
              setFileName(null)
              setFileError(null)
            }}
            className="inline-flex items-center gap-1.5 text-sm font-medium text-ink-600 hover:text-ink-950 dark:text-fog-300 dark:hover:text-mist-50"
          >
            <SparkleIcon className="h-4 w-4" />
            Try an example
          </button>
          <Button onClick={handleAnalyze} disabled={!hasContent || processingKind !== null} size="lg">
            Analyze with Gemma
          </Button>
        </div>
      </div>
    </div>
  )
}

'use client'

import { useEffect, useState } from 'react'
import { SparkleIcon } from './icons'

const STAGES = [
  'Reading your document…',
  'Finding key highlights…',
  'Finding key dates…',
  'Scanning for risks…',
  'Preparing your next steps…',
]

export default function ProcessingStep() {
  const [stageIndex, setStageIndex] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setStageIndex((i) => Math.min(i + 1, STAGES.length - 1))
    }, 1400)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="flex min-h-[420px] flex-col items-center justify-center text-center animate-fade-up">
      <div className="mb-6 flex h-14 w-14 items-center justify-center rounded-full bg-bridge-100 dark:bg-bridge-500/10">
        <SparkleIcon className="h-6 w-6 text-bridge-600 dark:text-bridge-500 animate-pulse-soft" />
      </div>
      <p className="font-display text-lg font-semibold">Gemma is analyzing your document</p>
      <p className="mt-2 text-sm text-ink-600 dark:text-fog-300" aria-live="polite">
        {STAGES[stageIndex]}
      </p>
      <div className="mt-6 h-1 w-48 overflow-hidden rounded-full bg-mist-200 dark:bg-ink-900">
        <div className="h-full w-1/3 rounded-full bg-bridge-500 animate-shimmer" />
      </div>
    </div>
  )
}

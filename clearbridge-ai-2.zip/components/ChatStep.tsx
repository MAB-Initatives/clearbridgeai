'use client'

import { useEffect, useRef, useState } from 'react'
import Button from './Button'
import { SendIcon, AlertTriangleIcon } from './icons'
import type { ChatMessage } from '@/lib/types'

const SUGGESTIONS = [
  'What happens if I miss the deadline?',
  'Explain this in French',
  'Explain this in Spanish',
  'What should I prepare first?',
]

interface ChatStepProps {
  messages: ChatMessage[]
  onSend: (message: string) => void
  isSending: boolean
  error: string | null
  onRetry: () => void
  onBackToResults: () => void
}

export default function ChatStep({
  messages,
  onSend,
  isSending,
  error,
  onRetry,
  onBackToResults,
}: ChatStepProps) {
  const [input, setInput] = useState('')
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' })
  }, [messages, isSending])

  function handleSend() {
    const trimmed = input.trim()
    if (!trimmed || isSending) return
    onSend(trimmed)
    setInput('')
  }

  return (
    <div className="flex h-[calc(100dvh-16rem)] min-h-[420px] max-h-[720px] flex-col animate-fade-up">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">Ask a follow-up</h1>
          <p className="mt-1 text-sm text-ink-600 dark:text-fog-300">
            Gemma remembers your document and this conversation.
          </p>
        </div>
        <Button variant="ghost" onClick={onBackToResults}>
          Back to results
        </Button>
      </div>

      <div
        ref={scrollRef}
        role="log"
        aria-live="polite"
        aria-label="Conversation with Gemma"
        className="flex-1 space-y-4 overflow-y-auto rounded-lg border border-mist-200 bg-white p-5 shadow-card dark:border-ink-900 dark:bg-ink-900/40"
      >
        {messages.length === 0 && (
          <div className="flex h-full flex-col items-center justify-center text-center">
            <p className="mb-4 text-sm text-ink-600 dark:text-fog-300">
              Ask anything about your document, or try:
            </p>
            <div className="flex flex-wrap justify-center gap-2">
              {SUGGESTIONS.map((s) => (
                <button
                  key={s}
                  onClick={() => onSend(s)}
                  className="rounded-full border border-mist-200 px-3 py-1.5 text-xs font-medium text-ink-600 transition-colors hover:border-bridge-500 hover:text-bridge-600 dark:border-ink-900 dark:text-fog-300"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div
              className={`max-w-[80%] rounded-md px-4 py-2.5 text-[15px] leading-relaxed ${
                m.role === 'user'
                  ? 'bg-bridge-600 text-white'
                  : 'bg-mist-100 text-ink-950 dark:bg-ink-900 dark:text-mist-50'
              }`}
            >
              {m.content}
            </div>
          </div>
        ))}

        {isSending && (
          <div className="flex justify-start">
            <div className="flex items-center gap-1.5 rounded-md bg-mist-100 px-4 py-3 dark:bg-ink-900">
              <span className="h-1.5 w-1.5 animate-pulse-soft rounded-full bg-ink-600 dark:bg-fog-300" />
              <span className="h-1.5 w-1.5 animate-pulse-soft rounded-full bg-ink-600 [animation-delay:150ms] dark:bg-fog-300" />
              <span className="h-1.5 w-1.5 animate-pulse-soft rounded-full bg-ink-600 [animation-delay:300ms] dark:bg-fog-300" />
            </div>
          </div>
        )}

        {error && (
          <div className="flex justify-start">
            <div className="max-w-[80%] rounded-md bg-error-100 px-4 py-3 text-sm text-error-700 dark:bg-error-600/10">
              <p className="mb-2 flex items-center gap-1.5 font-medium">
                <AlertTriangleIcon className="h-4 w-4" />
                {error}
              </p>
              <Button size="md" variant="secondary" onClick={onRetry}>
                Retry
              </Button>
            </div>
          </div>
        )}
      </div>

      <div className="mt-4 flex items-center gap-3">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault()
              handleSend()
            }
          }}
          placeholder="Ask a question about your document…"
          className="h-12 flex-1 rounded-md border border-mist-200 bg-mist-50 px-4 text-[15px] text-ink-950 placeholder:text-fog-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bridge-500 dark:border-ink-900 dark:bg-ink-950 dark:text-mist-50"
        />
        <Button onClick={handleSend} disabled={!input.trim() || isSending} size="lg">
          <SendIcon className="h-4 w-4" />
          Send
        </Button>
      </div>
    </div>
  )
}

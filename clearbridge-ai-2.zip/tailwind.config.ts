import type { Config } from 'tailwindcss'

const config: Config = {
  darkMode: 'class',
  content: [
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        bridge: {
          100: '#E8EDFF',
          500: '#3E68FF',
          600: '#2954E8',
          700: '#1E3FBD',
        },
        ink: {
          950: '#0B0D12',
          900: '#14161C',
          600: '#545A6B',
        },
        fog: {
          300: '#B4B8C5',
          500: '#7B8094',
        },
        mist: {
          0: '#FFFFFF',
          50: '#F8F9FB',
          100: '#F3F5F9',
          200: '#E7EAF1',
        },
        success: {
          100: '#E4F7EF',
          600: '#17A673',
          700: '#0F8F5E',
        },
        warning: {
          100: '#FFF4E3',
          600: '#C97A12',
          700: '#A8630C',
        },
        error: {
          100: '#FDEAEA',
          600: '#E23D3D',
          700: '#C22E2E',
        },
      },
      fontFamily: {
        display: ['var(--font-manrope)'],
        body: ['var(--font-inter)'],
        mono: ['var(--font-mono)'],
      },
      borderRadius: {
        sm: '8px',
        md: '12px',
        lg: '16px',
        xl: '24px',
      },
      boxShadow: {
        card: '0 1px 2px rgba(11,13,18,0.04), 0 8px 24px rgba(11,13,18,0.06)',
      },
    },
  },
  plugins: [],
}
export default config

// Prepares a user-selected/captured image for upload: validates type and
// size, then downscales and recompresses it via canvas so the resulting
// base64 payload reliably fits Netlify's request limits. Deliberately
// separate from analysis logic — this file only ever produces
// { mimeType, data, previewUrl, width, height }, and knows nothing about
// Gemma, the analyze pipeline, or the app's data model beyond that shape.

export const ACCEPTED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp']

// Netlify's buffered function request limit is 6MB; base64 adds ~30%
// overhead, so ~4.5MB of original image bytes is the effective ceiling.
// This is checked BEFORE compression, as a "is this even a sane file"
// guard — the compression step below does the real work of getting under
// the limit for anything that passes this.
const MAX_INPUT_BYTES = 20 * 1024 * 1024 // 20MB — reject absurdly large files early
const MAX_OUTPUT_BYTES = 4 * 1024 * 1024 // target ceiling after compression, with headroom
const MAX_DIMENSION = 2000 // px, longest side — keeps document text legible
const JPEG_QUALITY = 0.85

export interface PreparedImage {
  mimeType: string
  data: string // base64, no data: prefix
  previewUrl: string // object URL for <img> preview
  sizeLabel: string
}

export function isAcceptedImageType(file: File): boolean {
  return ACCEPTED_IMAGE_TYPES.includes(file.type)
}

function formatSize(bytes: number): string {
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
}

function loadImage(file: File): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file)
    const img = new Image()
    img.onload = () => resolve(img)
    img.onerror = () => {
      URL.revokeObjectURL(url)
      reject(new Error('That image could not be read.'))
    }
    img.src = url
  })
}

function canvasToBlob(canvas: HTMLCanvasElement, quality: number): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => (blob ? resolve(blob) : reject(new Error('Could not process that image.'))),
      'image/jpeg',
      quality
    )
  })
}

function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => {
      const result = String(reader.result || '')
      // strip the "data:image/jpeg;base64," prefix — Gemma's API wants raw base64
      const commaIndex = result.indexOf(',')
      resolve(commaIndex >= 0 ? result.slice(commaIndex + 1) : result)
    }
    reader.onerror = () => reject(new Error('Could not read that image.'))
    reader.readAsDataURL(blob)
  })
}

/**
 * Validates and prepares an image file for upload. Always re-encodes as
 * JPEG (simplest single output format for the backend to handle) and
 * downscales if needed. Throws a user-facing Error message on failure —
 * callers should catch and display err.message directly.
 */
export async function prepareImage(file: File): Promise<PreparedImage> {
  if (!isAcceptedImageType(file)) {
    throw new Error('Please choose a JPG, PNG, or WEBP image.')
  }
  if (file.size > MAX_INPUT_BYTES) {
    throw new Error(`That image is too large (${formatSize(file.size)}). Try a smaller photo.`)
  }

  const img = await loadImage(file)
  const scale = Math.min(1, MAX_DIMENSION / Math.max(img.width, img.height))
  const width = Math.round(img.width * scale)
  const height = Math.round(img.height * scale)

  const canvas = document.createElement('canvas')
  canvas.width = width
  canvas.height = height
  const ctx = canvas.getContext('2d')
  if (!ctx) throw new Error('Your browser could not process that image.')
  ctx.drawImage(img, 0, 0, width, height)
  URL.revokeObjectURL(img.src)

  let blob = await canvasToBlob(canvas, JPEG_QUALITY)

  // If still too large (rare — e.g. an extremely text-dense/high-entropy
  // photo), try one lower-quality pass before giving up.
  if (blob.size > MAX_OUTPUT_BYTES) {
    blob = await canvasToBlob(canvas, 0.6)
  }
  if (blob.size > MAX_OUTPUT_BYTES) {
    throw new Error('That photo is too large even after compression. Try cropping it closer to the document.')
  }

  const data = await blobToBase64(blob)
  const previewUrl = URL.createObjectURL(blob)

  return {
    mimeType: 'image/jpeg',
    data,
    previewUrl,
    sizeLabel: formatSize(blob.size),
  }
}

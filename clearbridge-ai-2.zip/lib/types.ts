export interface KeyDate {
  label: string
  date: string
  /** Normalized YYYY-MM-DD if Gemma could confidently determine one, else "". */
  iso_date: string
}

export interface EvidencedPoint {
  point: string
  /** Short supporting quote or close paraphrase from the document, or "" if none applies. */
  quote: string
}

export interface NextStep {
  action: string
  /** Why this step matters, grounded in the document. */
  reason: string
  /** Short supporting quote or close paraphrase from the document, or "" if none applies. */
  quote: string
}

export interface AnalysisResult {
  /** One-sentence verdict — the single most important takeaway. */
  bottom_line: string
  summary: string
  key_highlights: EvidencedPoint[]
  key_dates: KeyDate[]
  risks: EvidencedPoint[]
  next_steps: NextStep[]
}

export interface ChatMessage {
  role: 'user' | 'assistant'
  content: string
}

/** The uploaded document, in whichever form it arrived. Everything downstream
 * of this (analysis, chat, rendering) is identical regardless of which case
 * it is — only the two functions' request-building branches on it. */
export type DocumentInput =
  | { type: 'text'; text: string }
  | { type: 'image'; mimeType: string; data: string }

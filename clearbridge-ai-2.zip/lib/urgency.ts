export type UrgencyTone = 'urgent' | 'soon' | 'normal' | 'passed'

export interface Urgency {
  label: string
  tone: UrgencyTone
}

/**
 * Computes a human-readable urgency label from a normalized YYYY-MM-DD date.
 * Returns null if the date is missing or unparseable, so callers can fall
 * back to showing the document's own date text with no badge — never throw.
 */
export function getUrgency(isoDate: string | undefined | null): Urgency | null {
  if (!isoDate) return null
  const target = new Date(`${isoDate}T23:59:59`)
  if (Number.isNaN(target.getTime())) return null

  const msPerDay = 1000 * 60 * 60 * 24
  const daysRemaining = Math.ceil((target.getTime() - Date.now()) / msPerDay)

  if (daysRemaining < 0) return { label: 'Passed', tone: 'passed' }
  if (daysRemaining === 0) return { label: 'Today', tone: 'urgent' }
  if (daysRemaining === 1) return { label: 'Tomorrow', tone: 'urgent' }
  if (daysRemaining <= 7) return { label: `In ${daysRemaining} days`, tone: 'urgent' }
  if (daysRemaining <= 30) return { label: `In ${daysRemaining} days`, tone: 'soon' }
  return { label: `In ${Math.round(daysRemaining / 30)} months`, tone: 'normal' }
}

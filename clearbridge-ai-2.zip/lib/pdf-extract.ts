// Reads uploaded .txt/.md files using the browser's native FileReader.
// PDF support was deliberately left out: it required loading a third-party
// parser from a CDN at runtime, which is an untested, external dependency
// that could fail during a live demo. Paste and .txt/.md are the two paths
// that are fully working, so those are what's supported. See README.md
// "Known limitations" for the plan to add it back with a testing pass.

export async function extractTextFromFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(String(reader.result || ''))
    reader.onerror = () => reject(new Error('Could not read that file.'))
    reader.readAsText(file)
  })
}

'use client'

import { useState } from 'react'
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import UploadStep from '@/components/UploadStep'
import ProcessingStep from '@/components/ProcessingStep'
import ErrorStep from '@/components/ErrorStep'
import ResultsStep from '@/components/ResultsStep'
import ChatStep from '@/components/ChatStep'
import type { AnalysisResult, ChatMessage, DocumentInput } from '@/lib/types'

type Step = 'upload' | 'processing' | 'results' | 'chat' | 'error'

function isValidAnalysis(a: unknown): a is AnalysisResult {
  if (!a || typeof a !== 'object') return false
  const r = a as Record<string, unknown>
  return (
    typeof r.bottom_line === 'string' &&
    typeof r.summary === 'string' &&
    Array.isArray(r.key_highlights) &&
    Array.isArray(r.key_dates) &&
    Array.isArray(r.risks) &&
    Array.isArray(r.next_steps)
  )
}

export default function AssistantPage() {
  const [step, setStep] = useState<Step>('upload')
  const [documentInput, setDocumentInput] = useState<DocumentInput | null>(null)
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null)
  const [analyzeError, setAnalyzeError] = useState<string | null>(null)

  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([])
  const [isChatSending, setIsChatSending] = useState(false)
  const [chatError, setChatError] = useState<string | null>(null)
  const [lastFailedMessage, setLastFailedMessage] = useState<string | null>(null)

  async function runAnalysis(input: DocumentInput) {
    setDocumentInput(input)
    setStep('processing')
    setAnalyzeError(null)
    try {
      const res = await fetch('/.netlify/functions/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(
          input.type === 'text'
            ? { text: input.text }
            : { image: { mimeType: input.mimeType, data: input.data } }
        ),
      })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) {
        throw new Error(data.error || 'Something went wrong analyzing that document.')
      }
      if (!isValidAnalysis(data.analysis)) {
        throw new Error("Gemma's response was incomplete. Please try again.")
      }
      setAnalysis(data.analysis)
      setChatMessages([])
      setStep('results')
    } catch (err) {
      setAnalyzeError(err instanceof Error ? err.message : 'Something went wrong. Please try again.')
      setStep('error')
    }
  }

  function handleStartOver() {
    setStep('upload')
    setAnalyzeError(null)
  }

  async function callChatApi(message: string, historyForApi: ChatMessage[]) {
    setIsChatSending(true)
    try {
      const documentField =
        documentInput?.type === 'image'
          ? { documentImage: { mimeType: documentInput.mimeType, data: documentInput.data } }
          : { documentText: documentInput?.type === 'text' ? documentInput.text : '' }
      const res = await fetch('/.netlify/functions/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...documentField, history: historyForApi, message }),
      })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) {
        throw new Error(data.error || 'Gemma could not answer that. Please try again.')
      }
      setChatMessages((prev) => [...prev, { role: 'assistant', content: data.reply }])
      setLastFailedMessage(null)
      setChatError(null)
    } catch (err) {
      setChatError(err instanceof Error ? err.message : 'Something went wrong. Please try again.')
      setLastFailedMessage(message)
    } finally {
      setIsChatSending(false)
    }
  }

  function sendChatMessage(message: string) {
    setChatError(null)
    const hasDanglingUserTurn =
      chatMessages.length > 0 && chatMessages[chatMessages.length - 1].role === 'user'
    const historyForApi = hasDanglingUserTurn ? chatMessages.slice(0, -1) : chatMessages
    setChatMessages([...historyForApi, { role: 'user', content: message }])
    callChatApi(message, historyForApi)
  }

  function retryLastMessage() {
    if (!lastFailedMessage) return
    setChatError(null)
    const historyForApi = chatMessages.slice(0, -1)
    callChatApi(lastFailedMessage, historyForApi)
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar variant="assistant" />
      <main className="mx-auto w-full max-w-3xl flex-1 px-4 py-10 sm:px-6 sm:py-14">
        {step === 'upload' && <UploadStep onAnalyze={runAnalysis} />}
        {step === 'processing' && <ProcessingStep />}
        {step === 'error' && (
          <ErrorStep
            message={analyzeError || 'Something went wrong.'}
            onRetry={() => documentInput && runAnalysis(documentInput)}
            onStartOver={handleStartOver}
          />
        )}
        {step === 'results' && analysis && (
          <ResultsStep
            analysis={analysis}
            onAskFollowUp={() => setStep('chat')}
            onAnalyzeAnother={handleStartOver}
          />
        )}
        {step === 'chat' && (
          <ChatStep
            messages={chatMessages}
            onSend={sendChatMessage}
            isSending={isChatSending}
            error={chatError}
            onRetry={retryLastMessage}
            onBackToResults={() => setStep('results')}
          />
        )}
      </main>
      <Footer />
    </div>
  )
}

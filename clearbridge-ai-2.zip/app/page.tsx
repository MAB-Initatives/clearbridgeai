import Link from 'next/link'
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import Button from '@/components/Button'
import GemmaBadge from '@/components/GemmaBadge'
import { ClockIcon, ListChecksIcon, AlertTriangleIcon, ArrowRightIcon } from '@/components/icons'

const capabilities = [
  { label: 'Explains what it means', detail: 'Plain English, no jargon, no legal or technical filler.' },
  { label: 'Flags dates and risks', detail: 'Deadlines and clauses you could easily miss, called out clearly.' },
  { label: 'Tells you what to do', detail: 'A concrete next step — not a summary you still have to act on.' },
]

export default function LandingPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar variant="landing" />
      <main className="flex-1">
        <section className="mx-auto max-w-4xl px-4 pb-14 pt-16 text-center sm:px-6 sm:pt-24">
          <div className="mb-5 flex justify-center sm:hidden">
            <GemmaBadge />
          </div>
          <h1 className="font-display text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl">
            Upload any document.
            <br />
            Know exactly what to do <span className="text-bridge-600 dark:text-bridge-500">next</span>.
          </h1>
          <p className="mx-auto mt-5 max-w-xl text-[17px] leading-relaxed text-ink-600 dark:text-fog-300">
            ClearBridge AI is an AI decision assistant, not a summarizer. Upload a scholarship,
            contract, form, or policy — Gemma reads it and tells you what it means, what&apos;s at
            risk, and what to do next.
          </p>
          <div className="mt-8 flex items-center justify-center">
            <Link href="/assistant">
              <Button size="lg">
                Analyze a document
                <ArrowRightIcon className="h-4 w-4" />
              </Button>
            </Link>
          </div>
        </section>

        {/* Live example: document in, decision out */}
        <section className="mx-auto max-w-4xl px-4 sm:px-6">
          <div className="overflow-hidden rounded-lg border border-mist-200 bg-white shadow-card dark:border-ink-900 dark:bg-ink-900/40">
            <div className="border-b border-mist-200 p-6 dark:border-ink-900">
              <p className="mb-2 font-mono text-xs uppercase tracking-wide text-ink-600 dark:text-fog-300">
                Document
              </p>
              <p className="text-[15px] leading-relaxed text-ink-600 dark:text-fog-300">
                &ldquo;Applicants must have a WAEC result with a minimum of 5 credits including
                English and Mathematics. Completed applications, along with certified copies of
                the WAEC result, birth certificate, and passport photograph, must be received no
                later than August 15. Late or incomplete submissions will not be considered.&rdquo;
              </p>
            </div>
            <div className="grid grid-cols-1 divide-y divide-mist-200 dark:divide-ink-900 sm:grid-cols-3 sm:divide-x sm:divide-y-0">
              <div className="p-6">
                <div className="mb-2 flex items-center gap-2 text-bridge-600 dark:text-bridge-500">
                  <ClockIcon className="h-4 w-4" />
                  <p className="font-display text-sm font-semibold">Key date</p>
                </div>
                <p className="text-sm text-ink-600 dark:text-fog-300">Closes August 15 — no late submissions.</p>
              </div>
              <div className="p-6">
                <div className="mb-2 flex items-center gap-2 text-bridge-600 dark:text-bridge-500">
                  <ListChecksIcon className="h-4 w-4" />
                  <p className="font-display text-sm font-semibold">You need</p>
                </div>
                <p className="text-sm text-ink-600 dark:text-fog-300">WAEC result, birth certificate, passport photo.</p>
              </div>
              <div className="bg-bridge-100/50 p-6 dark:bg-bridge-600/10">
                <div className="mb-2 flex items-center gap-2 text-bridge-600 dark:text-bridge-500">
                  <ArrowRightIcon className="h-4 w-4" />
                  <p className="font-display text-sm font-semibold">Next step</p>
                </div>
                <p className="text-sm text-ink-950 dark:text-mist-50">Submit before August 10 to leave buffer time.</p>
              </div>
            </div>
          </div>
          <p className="mt-3 text-center text-xs text-ink-600 dark:text-fog-300">
            This is a real Gemma output format — not a mockup. Try it with your own document.
          </p>
        </section>

        <section className="mx-auto mt-16 max-w-4xl px-4 pb-20 sm:px-6">
          <div className="grid grid-cols-1 gap-8 sm:grid-cols-3">
            {capabilities.map((c) => (
              <div key={c.label}>
                <p className="font-display text-sm font-semibold">{c.label}</p>
                <p className="mt-1 text-sm text-ink-600 dark:text-fog-300">{c.detail}</p>
              </div>
            ))}
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}

import type { Metadata } from 'next'
import type { ReactNode } from 'react'
import { Manrope, Inter, JetBrains_Mono } from 'next/font/google'
import './globals.css'

const manrope = Manrope({ subsets: ['latin'], variable: '--font-manrope', display: 'swap' })
const inter = Inter({ subsets: ['latin'], variable: '--font-inter', display: 'swap' })
const mono = JetBrains_Mono({
  subsets: ['latin'],
  weight: ['400', '500'],
  variable: '--font-mono',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'ClearBridge AI — Your AI Decision Assistant',
  description:
    'Upload any document — a scholarship, contract, form, or policy — and ClearBridge AI, powered by Gemma, tells you what it means, what is at risk, and exactly what to do next.',
}

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html
      lang="en"
      className={`${manrope.variable} ${inter.variable} ${mono.variable}`}
      suppressHydrationWarning
    >
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function () {
                try {
                  var stored = localStorage.getItem('clearbridge-theme');
                  var theme = stored || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
                  if (theme === 'dark') document.documentElement.classList.add('dark');
                } catch (e) {}
              })();
            `,
          }}
        />
      </head>
      <body className="font-body bg-mist-50 text-ink-950 antialiased dark:bg-ink-950 dark:text-mist-50">
        {children}
      </body>
    </html>
  )
}

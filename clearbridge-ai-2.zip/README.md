# ClearBridge AI

**An AI Decision Assistant, not a summarizer.**

Upload a scholarship, contract, tenancy agreement, job offer, or policy. Gemma reads it and
tells you — in plain English — what it means, what's at risk, and exactly what to do next. Then
you can ask it follow-up questions, in any of 140+ languages.

If Gemma were removed, ClearBridge has no product: every explanation, highlight, date, risk,
next step, and chat reply on screen is generated live by Gemma. Nothing is hardcoded or templated.

---

## Why this exists

Dense official documents (financial aid forms, leases, scholarship rules, job offers) are where
the stakes are highest and the language is worst. People don't just need a shorter version of the
text — they need to know: *Do I qualify? What's the deadline? What could go wrong? What do I do
right now?* ClearBridge answers all four in one pass, then stays available for follow-up
questions, which is what separates a decision assistant from a summarizer.

## How Gemma powers every part of the product

| Capability (from the brief) | Where it happens |
|---|---|
| Explain complex documents in plain English | `netlify/functions/analyze.js` → `summary` field, plus a one-sentence `bottom_line` verdict shown first |
| Highlight the important points, grounded in the source | `analyze.js` → `key_highlights` field — each point carries a short supporting quote from the document |
| Identify deadlines, with urgency | `analyze.js` → `key_dates` field (label + normalized date); urgency badges ("In 3 days", "Passed") computed client-side in `lib/urgency.ts` |
| Warn users about risks, grounded in the source | `analyze.js` → `risks` field — each risk carries a short supporting quote |
| Recommend actionable next steps, with reasoning | `analyze.js` → `next_steps` field — each step includes a reason and, where applicable, a supporting quote |
| Answer follow-up questions, document-only | `netlify/functions/chat.js` — off-topic questions are declined and redirected, by design |
| Maintain conversation context | `chat.js` resends the document + recent turns each call |
| Translate into supported languages | Handled naturally by Gemma in `chat.js` (try the "Explain this in French" suggestion) |
| Read a photographed document directly (no OCR) | `analyze.js`/`chat.js` — `image` / `documentImage` branch sends the photo as `inline_data`; Gemma's native multimodal understanding produces the identical schema output as text input |

A single call to `analyze.js` returns all of this as one structured, schema-validated JSON object,
with every highlight, risk, and recommendation traceable back to the document rather than being a
bare assertion — this is what makes it a decision brief rather than a summary.

## Architecture

```
Landing (/)                     — pitch + live example, one CTA
        │
        ▼
Assistant (/assistant)          — one page, four steps as state:

  ┌─ Upload ──────────┐   paste / drag-drop / .txt,.md / JPG,PNG,WEBP photo
  │  one action:      │   (only formats that are fully reliable — no
  │  "Analyze"        │    third-party parsers or CDN dependencies)
  └────────┬──────────┘
           ▼  POST /.netlify/functions/analyze  (Gemma, JSON schema mode)
  ┌─ Processing ──────┐
  │  staged, reassuring status messages
  └────────┬──────────┘
           ▼
  ┌─ Results ─────────┐   Explanation → Highlights → Dates → Risks → Next steps
  │  one action:      │
  │  "Ask a follow-up"│
  └────────┬──────────┘
           ▼  POST /.netlify/functions/chat  (Gemma, full context resent)
  ┌─ Chat ────────────┐
  │  one action: Send │
  └───────────────────┘
```

Upload → Processing → Results → Chat live inside a single client component
(`app/assistant/page.tsx`) rather than four separate routes, so no document or conversation state
has to survive a full page navigation during the demo.

## Stack

- **Next.js 14** (standard dynamic build, deployed via Netlify's Next.js Runtime) — frontend
- **Netlify Functions** — two serverless endpoints (`analyze`, `chat`) that call Gemma server-side,
  keeping the API key off the client
- **Gemma 4** via Google AI Studio / Gemini API (see `GEMMA_MODEL` default in
  `netlify/functions/analyze.js` — override with the `GEMMA_MODEL` env var)
- **Tailwind CSS** with a small custom design token set (trustworthy blue, neutral grays, light +
  dark mode)
- No auth, no database, no payment — intentionally, to keep the MVP scoped to what's judged

## Local setup

```bash
npm install
cp .env.example .env      # add your GEMINI_API_KEY
npm run dev                # frontend at localhost:3000
```

The frontend calls `/.netlify/functions/analyze` and `/.netlify/functions/chat`. To run the
functions locally too, use the [Netlify CLI](https://docs.netlify.com/cli/get-started/):

```bash
npm install -g netlify-cli
netlify dev
```

## Deploying to Netlify

1. Push this repo to GitHub/GitLab.
2. In Netlify: **Add new site → Import an existing project**, and pick the repo.
   Netlify reads `netlify.toml` for the build command (`npm run build`), publish directory
   (`.next`), and functions directory (`netlify/functions`). Netlify's Next.js Runtime plugin
   auto-attaches to build `.next` into the serverless/CDN setup Next.js needs — no manual plugin
   install required.
3. In **Site settings → Environment variables**, add:
   - `GEMINI_API_KEY` — from [aistudio.google.com/app/apikey](https://aistudio.google.com/app/apikey)
   - `GEMMA_MODEL` *(optional)* — see the default in `netlify/functions/analyze.js` if unset
4. Deploy. That's it — no database, no auth provider, nothing else to configure.

> Note: no `package-lock.json` is committed. Netlify will generate one on first install; commit it
> back afterward for reproducible builds.

### If the build fails with a "publish directory" error

If a site was ever connected through Netlify's UI setup wizard, it can save its own Publish
Directory setting that *overrides* `netlify.toml` — check the failed build's resolved config for
`publishOrigin: ui`. If you see that, go to **Site configuration → Build & deploy → Build
settings** and either clear the Publish directory field (so `netlify.toml`'s `.next` takes over)
or set it to `.next` explicitly, then redeploy.

If the build log shows an "Outdated plugins" warning for `@netlify/plugin-nextjs`, that's Netlify
telling you a newer Next.js Runtime is available — safe to ignore for a hackathon deploy, but if
you hit a Runtime-specific bug, upgrading it is done from **Site configuration → Build & deploy →
Build plugins** in the dashboard, not from this repo.

## Judging criteria checklist

- **Gemma Integration (30%)** — Gemma performs 7+ distinct tasks (explain, extract highlights,
  extract dates, flag risks, recommend next steps, answer document-scoped follow-ups, translate)
  across two endpoints, using schema-constrained structured output for reliability. The "Powered
  by Gemma" badge is visible on every screen.
- **Innovation & Impact (30%)** — positioned and built as a decision assistant: every analysis
  ends with a numbered, prioritized action list, not a summary the user still has to interpret.
- **Functionality (20%)** — five required screens, one primary action per screen, every
  loading state reassures, every failure explains why and offers Retry, no scope creep (no auth /
  payment / dashboards / admin).
- **Presentation & Writeup (20%)** — consistent design system (spacing, type, color, components)
  across every screen, light/dark mode, accessible contrast and focus states, and this document.

## Known limitations / next steps

- **Photos of documents (JPG/PNG/WEBP) are analyzed by Gemma directly — no OCR step.** Confirmed
  against Google's own docs that Gemma 4 models read images natively via `inline_data`, so
  a photographed document goes through the exact same prompt/schema/parsing pipeline as pasted
  text (`lib/image-prepare.ts` + the `image` branch in both Netlify Functions). Client-side
  compression (canvas resize + recompress) keeps uploads under Netlify's effective ~4.5MB image
  limit (6MB request cap, minus ~30% base64 overhead) — this is a real platform constraint, not a
  nicety, since real phone photos routinely exceed it uncompressed. Photo quality (blur, skew,
  lighting) affects Gemma's ability to read the document the way it would a person; that's an
  inherent limit of the input, not something client-side code can fully correct.
- **No PDF upload yet, by choice.** An earlier version extracted PDF text client-side via a
  CDN-loaded parser; it was removed because it was untested and added a live network dependency
  with real risk of failing mid-demo. Now that image input is wired up via Gemma's native
  multimodal support, the natural next step for PDF is the same mechanism (render pages to images,
  or send the PDF directly as `inline_data`) rather than a client-side parsing library — but that's
  deliberately out of scope for this pass.
- Chat is intentionally document-only — it declines and redirects off-topic questions rather than
  answering them, so it can't be used as a general chatbot.
- Chat context (text or image) is resent each turn rather than using a persisted session — simple
  and reliable for an MVP, would move to server-side session state for longer conversations.

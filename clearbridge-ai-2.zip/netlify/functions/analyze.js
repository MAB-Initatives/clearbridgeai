// Netlify Function: /.netlify/functions/analyze
// Calls Gemma (via Google AI Studio / Gemini API) to answer, in one structured
// call, the five questions every result must answer: what this document is,
// what the important points are, what dates/requirements exist, what risks
// to watch for, and what to do next — with each highlight, risk, and
// recommendation grounded in a short quote or explanation from the document
// itself, and a single-sentence bottom-line verdict up front.
//
// Accepts either { text } or { image: { mimeType, data } } — Gemma 4 reads
// images natively via inline_data, so a photographed document goes through
// this exact same pipeline (same prompt, same schema, same parsing) as
// pasted text. Only buildContentParts() below knows the difference.
//
// Requires env var: GEMINI_API_KEY (create one at aistudio.google.com/app/apikey)
// Optional env var: GEMMA_MODEL (defaults to gemma-4-12b-it)

const GEMMA_MODEL = process.env.GEMMA_MODEL || 'gemma-4-12b-it'
const API_BASE = 'https://generativelanguage.googleapis.com/v1beta/models'
const ACCEPTED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp']
const MAX_TEXT_LENGTH = 20000
// ~4.5MB of original image bytes, base64-inflated (~33%) — matches the
// client-side compression target in lib/image-prepare.ts, with headroom.
const MAX_IMAGE_BASE64_LENGTH = 6_000_000

/** Thrown for expected, user-facing validation problems (as opposed to
 * unexpected failures) so the handler can respond with 400 + the message
 * rather than a generic 502. */
class UserError extends Error {}

function buildSystemInstruction() {
  const today = new Date().toISOString().slice(0, 10)
  return `You are Gemma, the core intelligence of ClearBridge AI, an AI Decision Assistant.
You read real documents (scholarships, contracts, tenancy agreements, forms, job offers, policies) and produce a short decision brief: what this is, what matters most, what dates/requirements exist, what's risky, and what to do next.

Today's date is ${today}. Only use this to reason about how much time remains until a date mentioned in the document — never assume you already know the current date otherwise.

Rules:
- Write a one-sentence "bottom line": the single most important takeaway, stated as a direct verdict (e.g. "You qualify, but must submit before August 15."). Reference actual dates/facts from the document, not vague relative time.
- Explain the document in plain, everyday English. No legal or technical jargon.
- List the important points a reader must not miss — eligibility conditions, obligations, amounts, key terms. For each, include a short supporting quote or close paraphrase from the document (under 15 words), or an empty string if nothing directly supports it.
- Extract concrete deadlines and dates exactly as stated in the document's own words. Also provide a normalized YYYY-MM-DD version of each date if you can confidently determine one from context (e.g. inferring the year from other dates in the document) — otherwise leave it as an empty string. Never invent a date that isn't stated.
- Identify real risks, penalties, or details the reader could easily miss or misunderstand, each with a short supporting quote or paraphrase (under 15 words), or an empty string if none applies.
- Recommend specific, actionable next steps, ordered by priority, phrased as direct instructions (e.g. "Submit your application by August 10"). For each step, give a short reason grounded in the document explaining why it matters, and a short supporting quote or paraphrase (under 15 words) if one applies, or an empty string if not.
- Be concrete: reference the actual numbers, names, and dates in the document rather than generic advice.
- Return only the fields defined by the response schema — no extra commentary.`
}

const EVIDENCED_POINT_SCHEMA = {
  type: 'object',
  properties: {
    point: { type: 'string' },
    quote: { type: 'string' },
  },
  required: ['point', 'quote'],
}

const RESPONSE_SCHEMA = {
  type: 'object',
  properties: {
    bottom_line: { type: 'string' },
    summary: {
      type: 'string',
      description:
        'A plain-English explanation of what this document is and what it means for the reader. 3-6 sentences.',
    },
    key_highlights: { type: 'array', items: EVIDENCED_POINT_SCHEMA },
    key_dates: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          label: { type: 'string' },
          date: { type: 'string' },
          iso_date: { type: 'string' },
        },
        required: ['label', 'date', 'iso_date'],
      },
    },
    risks: { type: 'array', items: EVIDENCED_POINT_SCHEMA },
    next_steps: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          action: { type: 'string' },
          reason: { type: 'string' },
          quote: { type: 'string' },
        },
        required: ['action', 'reason', 'quote'],
      },
    },
  },
  required: ['bottom_line', 'summary', 'key_highlights', 'key_dates', 'risks', 'next_steps'],
}

/**
 * Turns the request body into Gemma `parts` for either input type. This is
 * the entire image-handling surface of this function — the prompt, schema,
 * API call, and response parsing below have no idea whether the document
 * arrived as text or a photo.
 */
function buildContentParts(body) {
  if (body.image) {
    const { mimeType, data } = body.image || {}
    if (!mimeType || !ACCEPTED_IMAGE_TYPES.includes(mimeType)) {
      throw new UserError('Please upload a JPG, PNG, or WEBP image.')
    }
    if (!data || typeof data !== 'string') {
      throw new UserError('That image could not be read. Please try again.')
    }
    if (data.length > MAX_IMAGE_BASE64_LENGTH) {
      throw new UserError('That image is too large. Try a smaller or more compressed photo.')
    }
    return [
      { inline_data: { mime_type: mimeType, data } },
      { text: 'Analyze the document shown in this image.' },
    ]
  }

  const text = body.text
  if (!text || !text.trim()) {
    throw new UserError('Paste or upload a document before analyzing.')
  }
  if (text.length > MAX_TEXT_LENGTH) {
    throw new UserError('That document is too long for a single analysis. Try a shorter excerpt.')
  }
  return [{ text }]
}

exports.handler = async function (event) {
  if (event.httpMethod !== 'POST') {
    return respond(405, { error: 'Method not allowed.' })
  }

  let body
  try {
    body = JSON.parse(event.body || '{}')
  } catch (e) {
    return respond(400, { error: 'That request was malformed. Please try again.' })
  }

  let parts
  try {
    parts = buildContentParts(body)
  } catch (err) {
    if (err instanceof UserError) {
      return respond(400, { error: err.message })
    }
    throw err
  }

  const apiKey = process.env.GEMINI_API_KEY
  if (!apiKey) {
    return respond(500, {
      error: "ClearBridge isn't configured yet. Add a GEMINI_API_KEY environment variable in Netlify, then redeploy.",
    })
  }

  try {
    const response = await fetch(`${API_BASE}/${GEMMA_MODEL}:generateContent`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-goog-api-key': apiKey,
      },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: buildSystemInstruction() }] },
        contents: [{ role: 'user', parts }],
        generationConfig: {
          responseMimeType: 'application/json',
          responseSchema: RESPONSE_SCHEMA,
          temperature: 0.3,
          // Gemma 4 defaults to an internal "thinking" pass that can add 20-30s+
          // of latency on structured-output requests like this one, which is
          // long enough to hit Netlify's ~30s function timeout. MINIMAL is the
          // verified-working way to suppress it (includeThoughts:false is
          // silently ignored on Gemma 4).
          thinkingConfig: { thinkingLevel: 'MINIMAL' },
        },
      }),
    })

    if (!response.ok) {
      const errText = await response.text()
      console.error('Gemma analyze error:', response.status, errText)
      return respond(502, { error: 'Gemma is temporarily unavailable. Please try again in a moment.' })
    }

    const data = await response.json()
    const rawText = extractText(data)

    if (!rawText) {
      return respond(502, { error: 'Gemma returned an empty analysis. Please try again.' })
    }

    let analysis
    try {
      analysis = JSON.parse(rawText)
    } catch (e) {
      console.error('Failed to parse Gemma JSON:', rawText)
      return respond(502, { error: "Gemma's response couldn't be read. Please try again." })
    }

    if (!isValidAnalysis(analysis)) {
      console.error('Gemma JSON missing expected fields:', rawText)
      return respond(502, { error: "Gemma's response was incomplete. Please try again." })
    }

    return respond(200, { analysis })
  } catch (err) {
    console.error('Analyze function error:', err)
    return respond(502, { error: 'Something went wrong reaching Gemma. Please try again.' })
  }
}

function isValidAnalysis(a) {
  return (
    a &&
    typeof a.bottom_line === 'string' &&
    typeof a.summary === 'string' &&
    Array.isArray(a.key_highlights) &&
    Array.isArray(a.key_dates) &&
    Array.isArray(a.risks) &&
    Array.isArray(a.next_steps)
  )
}

function extractText(data) {
  const candidate = data.candidates && data.candidates[0]
  const parts = candidate && candidate.content && candidate.content.parts
  if (!parts) return ''
  return parts
    // Gemma 4 can return "thought" parts (internal reasoning) even when
    // thinking is nominally minimized — they still carry a .text field, so
    // without this filter they get concatenated onto the real answer and
    // corrupt it (e.g. a half-formed JSON draft glued onto the final JSON).
    .filter((p) => typeof p.text === 'string' && !p.thought)
    .map((p) => p.text)
    .join('')
    .trim()
}

function respond(statusCode, bodyObj) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(bodyObj),
  }
}

// Netlify Function: /.netlify/functions/chat
// Handles follow-up questions about an already-analyzed document, keeping
// Gemma "in context" by resending the document plus recent turns each call.
//
// Accepts either { documentText } or { documentImage: { mimeType, data } } —
// whichever form the original upload was, so follow-up chat stays grounded
// in the same source material the analysis used. Only
// buildDocumentContextParts() below knows the difference.
//
// Requires env var: GEMINI_API_KEY
// Optional env var: GEMMA_MODEL (defaults to gemma-4-12b-it)

const GEMMA_MODEL = process.env.GEMMA_MODEL || 'gemma-4-12b-it'
const API_BASE = 'https://generativelanguage.googleapis.com/v1beta/models'
const ACCEPTED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp']

const SYSTEM_INSTRUCTION = `You are Gemma, answering follow-up questions inside ClearBridge AI, an AI Decision Assistant.
The user has already uploaded a document, provided below as context. You only discuss this document — you are not a general-purpose assistant.

Rules:
- Answer strictly using the document provided. Light interpretation of what it means for the reader is fine; introducing outside facts is not.
- If a question is unrelated to the document (general knowledge, other topics, small talk unrelated to the task), politely decline and redirect the user back to asking about their document. Do not answer it.
- If the document doesn't contain the answer to an otherwise on-topic question, say so plainly rather than guessing.
- Keep answers short, plain-English, and actionable — end with what the user should do, when relevant.
- If asked to translate or explain the document in another language, respond fully in that language.`

/**
 * Builds the initial "here's the document" turn as either a text or image
 * part. This is the entire image-handling surface of this function.
 */
function buildDocumentContextParts(body) {
  const image = body.documentImage
  if (image && image.mimeType && image.data && ACCEPTED_IMAGE_TYPES.includes(image.mimeType)) {
    return [
      { inline_data: { mime_type: image.mimeType, data: image.data } },
      { text: 'This is the document being discussed in this conversation.' },
    ]
  }
  const documentText = body.documentText || ''
  return [{ text: `Document context:\n\n${documentText.slice(0, 20000)}` }]
}

exports.handler = async function (event) {
  if (event.httpMethod !== 'POST') {
    return respond(405, { error: 'Method not allowed.' })
  }

  let body, history, message
  try {
    body = JSON.parse(event.body || '{}')
    history = Array.isArray(body.history) ? body.history : []
    message = body.message
  } catch (e) {
    return respond(400, { error: 'That request was malformed. Please try again.' })
  }

  if (!message || !message.trim()) {
    return respond(400, { error: 'Type a question before sending.' })
  }

  const apiKey = process.env.GEMINI_API_KEY
  if (!apiKey) {
    return respond(500, {
      error: "ClearBridge isn't configured yet. Add a GEMINI_API_KEY environment variable in Netlify, then redeploy.",
    })
  }

  const contents = [
    { role: 'user', parts: buildDocumentContextParts(body) },
    { role: 'model', parts: [{ text: 'Understood — I have the document. Ask me anything about it.' }] },
  ]

  for (const turn of history.slice(-12)) {
    if (!turn || !turn.content) continue
    contents.push({
      role: turn.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: String(turn.content).slice(0, 4000) }],
    })
  }

  contents.push({ role: 'user', parts: [{ text: message }] })

  try {
    const response = await fetch(`${API_BASE}/${GEMMA_MODEL}:generateContent`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-goog-api-key': apiKey,
      },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: SYSTEM_INSTRUCTION }] },
        contents,
        generationConfig: {
          temperature: 0.4,
          // See analyze.js — same fix for the same reason: default Gemma 4
          // thinking latency can exceed Netlify's function timeout.
          thinkingConfig: { thinkingLevel: 'MINIMAL' },
        },
      }),
    })

    if (!response.ok) {
      const errText = await response.text()
      console.error('Gemma chat error:', response.status, errText)
      return respond(502, { error: 'Gemma is temporarily unavailable. Please try again in a moment.' })
    }

    const data = await response.json()
    const reply = extractText(data)

    if (!reply) {
      return respond(502, { error: 'Gemma returned an empty reply. Please try again.' })
    }

    return respond(200, { reply })
  } catch (err) {
    console.error('Chat function error:', err)
    return respond(502, { error: 'Something went wrong reaching Gemma. Please try again.' })
  }
}

function extractText(data) {
  const candidate = data.candidates && data.candidates[0]
  const parts = candidate && candidate.content && candidate.content.parts
  if (!parts) return ''
  return parts
    // See analyze.js — filters out leaked 'thought' parts that would
    // otherwise get concatenated onto the real reply text.
    .filter((p) => typeof p.text === 'string' && !p.thought)
    .map((p) => p.text)
    .join('')
    .trim()
}

function respond(statusCode, bodyObj) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(bodyObj),
  }
}
